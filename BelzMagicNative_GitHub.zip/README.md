# پروژه کاملاً بومی (Native) بلز جادویی با Jetpack Compose

این پروژه ۱۰۰٪ با **Kotlin** و **Jetpack Compose** نوشته شده و بدون نیاز به اینترنت و با استفاده از `AudioTrack` صدای واقعی بلز، ماریمبا و زنگ جادویی را تولید می‌کند.

## ساخت فایل APK در Android Studio:
1. فایل زیپ را استخراج کنید.
2. پوشه `BelzMagicNative` را در **Android Studio** باز کنید.
3. پس از اتمام Gradle Sync، از منوی بالا گزینه زیر را بزنید:
   `Build > Build Bundle(s) / APK(s) > Build APK(s)`
