package com.belzmagic.nativeapp

import androidx.compose.ui.graphics.Color

data class BelzNote(
    val id: Int,
    val en: String,
    val fa: String,
    val num: String,
    val freq: Double,
    val topColor: Color,
    val bottomColor: Color,
    val heightFraction: Float
)

data class SongNote(
    val noteId: Int,
    val beats: Float,
    val lyric: String = ""
)

data class KidsSong(
    val id: String,
    val title: String,
    val emoji: String,
    val level: String,
    val bpm: Int,
    val notes: List<SongNote>
)

data class MusicLesson(
    val id: String,
    val title: String,
    val desc: String,
    val steps: List<Int>,
    val reward: Int
)

val BELZ_NOTES = listOf(
    BelzNote(0,  "C5", "دو",   "۱",  523.25,  Color(0xFFFB7185), Color(0xFFE11D48), 1.00f),
    BelzNote(1,  "D5", "ر",    "۲",  587.33,  Color(0xFFFB923C), Color(0xFFEA580C), 0.97f),
    BelzNote(2,  "E5", "می",   "۳",  659.25,  Color(0xFFFCD34D), Color(0xFFEAB308), 0.94f),
    BelzNote(3,  "F5", "فا",   "۴",  698.46,  Color(0xFF34D399), Color(0xFF16A34A), 0.91f),
    BelzNote(4,  "G5", "سل",   "۵",  783.99,  Color(0xFF22D3EE), Color(0xFF0891B2), 0.88f),
    BelzNote(5,  "A5", "لا",   "۶",  880.00,  Color(0xFF3B82F6), Color(0xFF4F46E5), 0.85f),
    BelzNote(6,  "B5", "سی",   "۷",  987.77,  Color(0xFF8B5CF6), Color(0xFF6D28D9), 0.82f),
    BelzNote(7,  "C6", "دو+",  "۸",  1046.50, Color(0xFFF472B6), Color(0xFFDB2777), 0.79f),
    BelzNote(8,  "D6", "ر+",   "۹",  1174.66, Color(0xFFFB7185), Color(0xFFE11D48), 0.76f),
    BelzNote(9,  "E6", "می+",  "۱۰", 1318.51, Color(0xFFFB923C), Color(0xFFEA580C), 0.73f),
    BelzNote(10, "F6", "فا+",  "۱۱", 1396.91, Color(0xFFFCD34D), Color(0xFFEAB308), 0.70f),
    BelzNote(11, "G6", "سل+",  "۱۲", 1567.98, Color(0xFF34D399), Color(0xFF16A34A), 0.67f),
    BelzNote(12, "A6", "لا+",  "۱۳", 1760.00, Color(0xFF22D3EE), Color(0xFF0891B2), 0.64f),
    BelzNote(13, "B6", "سی+",  "۱۴", 1975.53, Color(0xFF3B82F6), Color(0xFF4F46E5), 0.61f),
    BelzNote(14, "C7", "دو++", "۱۵", 2093.00, Color(0xFF8B5CF6), Color(0xFF6D28D9), 0.58f)
)

val KIDS_SONGS = listOf(
    KidsSong(
        "twinkle", "ستاره کوچولو (کامل)", "🌟", "خیلی آسان", 105,
        listOf(
            SongNote(0, 1f, "ستـ"), SongNote(0, 1f, "اره"), SongNote(4, 1f, "کو"), SongNote(4, 1f, "چو"),
            SongNote(5, 1f, "لو"), SongNote(5, 1f, "بـ"), SongNote(4, 2f, "تاب"),
            SongNote(3, 1f, "در"), SongNote(3, 1f, "آسـ"), SongNote(2, 1f, "مان"), SongNote(2, 1f, "شـ"),
            SongNote(1, 1f, "ب"), SongNote(1, 1f, "بخـ"), SongNote(0, 2f, "واب"),
            SongNote(4, 1f, "با"), SongNote(4, 1f, "لا"), SongNote(3, 1f, "تـ"), SongNote(3, 1f, "ر"),
            SongNote(2, 1f, "از"), SongNote(2, 1f, "ابـ"), SongNote(1, 2f, "رها"),
            SongNote(4, 1f, "همـ"), SongNote(4, 1f, "چون"), SongNote(3, 1f, "الـ"), SongNote(3, 1f, "ماس"),
            SongNote(2, 1f, "در"), SongNote(2, 1f, "شـ"), SongNote(1, 2f, "بها"),
            SongNote(0, 1f, "ستـ"), SongNote(0, 1f, "اره"), SongNote(4, 1f, "کو"), SongNote(4, 1f, "چو"),
            SongNote(5, 1f, "لو"), SongNote(5, 1f, "بـ"), SongNote(4, 2f, "تاب"),
            SongNote(3, 1f, "در"), SongNote(3, 1f, "آسـ"), SongNote(2, 1f, "مان"), SongNote(2, 1f, "شـ"),
            SongNote(1, 1f, "ب"), SongNote(1, 1f, "بخـ"), SongNote(0, 2f, "واب")
        )
    ),
    KidsSong(
        "hozak_shadi", "لی لی حوضک (شادی امینی)", "🐥", "متوسط", 120,
        listOf(
            SongNote(5, 0.75f, "لی"), SongNote(5, 0.5f, "لی"), SongNote(5, 0.75f, "لی"),
            SongNote(7, 0.5f, "لی"), SongNote(7, 0.75f, "حو"), SongNote(7, 1.25f, "ضک"),
            SongNote(4, 1.0f, "جو"), SongNote(4, 1.0f, "جه"),
            SongNote(6, 1.5f, "او"), SongNote(5, 1.0f, "مد"), SongNote(5, 1.75f, "آب"),
            SongNote(8, 0.5f, "بـ"), SongNote(8, 0.5f, "خو"), SongNote(8, 0.25f, "ره"),
            SongNote(8, 0.25f, "افـ"), SongNote(8, 0.5f, "تاد"),
            SongNote(7, 0.25f, "تو"), SongNote(6, 0.25f, "ی"), SongNote(2, 0.5f, "حو"),
            SongNote(6, 0.5f, "ضک"), SongNote(5, 0.5f, "!"), SongNote(3, 0.75f, "!"),
            SongNote(8, 0.25f, "♪"), SongNote(8, 0.25f, "♪"), SongNote(8, 0.25f, "♪"),
            SongNote(8, 0.5f, "♪"), SongNote(8, 0.5f, "♪"),
            SongNote(7, 0.25f, "♪"), SongNote(6, 1.0f, "♪"), SongNote(6, 0.75f, "♪"), SongNote(5, 1.5f, "♪"),
            SongNote(8, 0.5f, "♪"), SongNote(8, 0.5f, "♪"), SongNote(8, 0.5f, "♪"),
            SongNote(6, 0.5f, "♪"), SongNote(2, 0.5f, "♪"), SongNote(6, 0.25f, "♪"),
            SongNote(5, 0.25f, "♪"), SongNote(6, 0.75f, "♪"), SongNote(5, 2.0f, "♪"),
            SongNote(8, 1.0f, "♪"), SongNote(2, 0.75f, "♪"), SongNote(7, 0.5f, "♪"), SongNote(6, 1.5f, "♪"),
            SongNote(4, 0.5f, "♪"), SongNote(3, 0.25f, "♪"), SongNote(4, 1.0f, "♪"),
            SongNote(4, 0.75f, "♪"), SongNote(5, 1.0f, "♪"), SongNote(2, 0.25f, "♪"),
            SongNote(5, 0.75f, "♪"), SongNote(2, 0.5f, "♪"), SongNote(4, 2.0f, "♪"),
            SongNote(4, 1.25f, "♪"), SongNote(5, 0.75f, "♪"), SongNote(5, 2.0f, "♪"),
            SongNote(2, 0.5f, "♪"), SongNote(4, 1.25f, "♪"), SongNote(5, 1.0f, "♪"), SongNote(2, 2.0f, "♪")
        )
    ),
    KidsSong(
        "tavalod_ir", "تولد تولد (ایرانی)", "🎂", "متوسط", 120,
        listOf(
            SongNote(4, 1f, "تـ"), SongNote(4, 1f, "ولـ"), SongNote(7, 2f, "د"),
            SongNote(4, 1f, "تـ"), SongNote(4, 1f, "ولـ"), SongNote(7, 2f, "د"),
            SongNote(4, 0.75f, "تـ"), SongNote(4, 0.75f, "ولـ"), SongNote(7, 1f, "دت"),
            SongNote(7, 0.75f, "مـ"), SongNote(6, 0.75f, "با"), SongNote(5, 0.75f, "ر"), SongNote(6, 2f, "ک"),
            SongNote(4, 1f, "مـ"), SongNote(4, 1f, "با"), SongNote(6, 2f, "رک"),
            SongNote(4, 1f, "مـ"), SongNote(4, 1f, "با"), SongNote(6, 2f, "رک"),
            SongNote(4, 0.75f, "تـ"), SongNote(4, 0.75f, "ولـ"), SongNote(5, 0.75f, "دت"),
            SongNote(4, 0.75f, "مـ"), SongNote(5, 0.75f, "با"), SongNote(6, 0.75f, "ر"), SongNote(7, 2f, "ک"),
            SongNote(4, 1f, "بیـا"), SongNote(5, 1f, "شمع"), SongNote(5, 1f, "ها"), SongNote(4, 1f, "رو"),
            SongNote(3, 1f, "فوت"), SongNote(2, 1f, "کن"), SongNote(1, 2f, "!"),
            SongNote(1, 1f, "که"), SongNote(2, 1f, "صد"), SongNote(2, 1f, "سال"),
            SongNote(1, 1f, "زنـ"), SongNote(2, 1f, "ده"), SongNote(1, 1f, "با"), SongNote(0, 2f, "شی")
        )
    ),
    KidsSong(
        "birthday", "تولدت مبارک (کامل)", "🥳", "خیلی آسان", 110,
        listOf(
            SongNote(4, 0.75f, "تو"), SongNote(4, 0.25f, "لـ"), SongNote(5, 1f, "دت"),
            SongNote(4, 1f, "مـ"), SongNote(7, 1f, "با"), SongNote(6, 2f, "رک"),
            SongNote(4, 0.75f, "تو"), SongNote(4, 0.25f, "لـ"), SongNote(5, 1f, "دت"),
            SongNote(4, 1f, "مـ"), SongNote(8, 1f, "با"), SongNote(7, 2f, "رک"),
            SongNote(4, 0.75f, "تو"), SongNote(4, 0.25f, "لـ"), SongNote(11, 1f, "دت"),
            SongNote(9, 1f, "مـ"), SongNote(7, 1f, "با"), SongNote(6, 1f, "ر"), SongNote(5, 2f, "ک"),
            SongNote(10, 0.75f, "تو"), SongNote(10, 0.25f, "لـ"), SongNote(9, 1f, "دت"),
            SongNote(7, 1f, "مـ"), SongNote(8, 1f, "با"), SongNote(7, 2f, "رک")
        )
    ),
    KidsSong(
        "bacheha", "بچه‌های ایران", "🇮🇷", "خیلی آسان", 112,
        listOf(
            SongNote(0, 1f, "بـ"), SongNote(1, 1f, "چه"), SongNote(2, 1f, "های"), SongNote(3, 1f, "ایـ"),
            SongNote(4, 1f, "ران"), SongNote(4, 1f, "همه"),
            SongNote(5, 1f, "خوش"), SongNote(5, 1f, "و"), SongNote(4, 1f, "خنـ"), SongNote(3, 1f, "دان"),
            SongNote(2, 1f, "!"), SongNote(2, 1f, "!"),
            SongNote(4, 1f, "خوب"), SongNote(4, 1f, "و"), SongNote(3, 1f, "مهـ"), SongNote(3, 1f, "ربو"),
            SongNote(1, 1f, "نیم"), SongNote(1, 1f, "چه"),
            SongNote(3, 1f, "خوش"), SongNote(3, 1f, "ز"), SongNote(2, 1f, "بو"), SongNote(1, 1f, "نیم"), SongNote(2, 2f, "!"),
            SongNote(0, 1f, "ما"), SongNote(1, 1f, "گلـ"), SongNote(2, 1f, "های"), SongNote(3, 1f, "با"),
            SongNote(4, 1f, "غیم"), SongNote(4, 1f, "خوب"),
            SongNote(5, 1f, "و"), SongNote(5, 1f, "خوش"), SongNote(4, 1f, "اخـ"), SongNote(3, 1f, "لا"),
            SongNote(2, 1f, "قیم"), SongNote(2, 1f, "!"),
            SongNote(4, 1f, "روز"), SongNote(4, 1f, "ها"), SongNote(3, 1f, "با"), SongNote(2, 1f, "بلـ"),
            SongNote(1, 1f, "بلـ"), SongNote(1, 1f, "ها"),
            SongNote(3, 1f, "آ"), SongNote(3, 1f, "واز"), SongNote(2, 1f, "میـ"), SongNote(1, 1f, "خو"), SongNote(0, 2f, "نیم")
        )
    ),
    KidsSong(
        "soltan", "سلطان قلبها", "❤️", "متوسط", 108,
        listOf(
            SongNote(5, 1f, "لا"), SongNote(6, 1f, "سی"), SongNote(7, 1f, "دو+"), SongNote(9, 1f, "می+"),
            SongNote(10, 0.75f, "یه"), SongNote(9, 0.75f, "دل"), SongNote(10, 0.75f, "میـ"), SongNote(9, 0.75f, "گه"),
            SongNote(10, 0.75f, "بـ"), SongNote(9, 1f, "رم"), SongNote(8, 1.5f, "بـرم"),
            SongNote(9, 0.75f, "یه"), SongNote(8, 0.75f, "دل"), SongNote(9, 0.75f, "میـ"), SongNote(8, 0.75f, "گه"),
            SongNote(9, 0.75f, "نـ"), SongNote(8, 1f, "رم"), SongNote(7, 1.5f, "نرم"),
            SongNote(8, 0.75f, "طا"), SongNote(7, 0.75f, "قت"), SongNote(8, 0.75f, "نـ"), SongNote(7, 0.75f, "دا"),
            SongNote(6, 1f, "ره"), SongNote(5, 2f, "دلم")
        )
    ),
    KidsSong(
        "mary", "بره کوچولوی من", "🐑", "آسان", 115,
        listOf(
            SongNote(2, 1f, "بـ"), SongNote(1, 1f, "ره"), SongNote(0, 1f, "کو"), SongNote(1, 1f, "چو"),
            SongNote(2, 1f, "لو"), SongNote(2, 1f, "ی"), SongNote(2, 2f, "من"),
            SongNote(1, 1f, "سـ"), SongNote(1, 1f, "فیـ"), SongNote(1, 2f, "ده"),
            SongNote(2, 1f, "مثل"), SongNote(4, 1f, "بر"), SongNote(4, 2f, "فه")
        )
    ),
    KidsSong(
        "bezanbaran", "بزن باران", "☔", "آسان", 110,
        listOf(
            SongNote(0, 1f, "بـ"), SongNote(2, 1f, "زن"), SongNote(4, 1f, "با"), SongNote(2, 1f, "را"), SongNote(0, 2f, "ن"),
            SongNote(1, 1f, "به"), SongNote(3, 1f, "با"), SongNote(5, 1f, "غ"), SongNote(3, 1f, "و"), SongNote(1, 2f, "دشت"),
            SongNote(2, 1f, "هـ"), SongNote(4, 1f, "وا"), SongNote(6, 1f, "خنـ"), SongNote(4, 1f, "ک"), SongNote(2, 2f, "شد"),
            SongNote(3, 1f, "ز"), SongNote(5, 1f, "میـ"), SongNote(7, 1f, "ن"), SongNote(5, 1f, "تـ"), SongNote(3, 2f, "ر")
        )
    ),
    KidsSong(
        "ghoghnoos", "ملودی ققنوس", "🔥", "متوسط", 112,
        listOf(
            SongNote(0, 1f, "دو"), SongNote(2, 1f, "می"), SongNote(3, 1f, "فا"), SongNote(4, 1f, "سل"),
            SongNote(3, 1f, "فا"), SongNote(2, 1f, "می"), SongNote(0, 2f, "دو"),
            SongNote(2, 1f, "می"), SongNote(4, 1f, "سل"), SongNote(5, 1f, "لا"), SongNote(6, 1f, "سی"),
            SongNote(5, 1f, "لا"), SongNote(4, 1f, "سل"), SongNote(2, 2f, "می"),
            SongNote(3, 1f, "فا"), SongNote(5, 1f, "لا"), SongNote(6, 1f, "سی"), SongNote(7, 1f, "دو+"),
            SongNote(6, 1f, "سی"), SongNote(5, 1f, "لا"), SongNote(3, 2f, "فا"),
            SongNote(4, 1f, "سل"), SongNote(6, 1f, "سی"), SongNote(7, 1f, "دو+"), SongNote(8, 1f, "ر+"),
            SongNote(7, 1f, "دو+"), SongNote(6, 1f, "سی"), SongNote(4, 2f, "سل")
        )
    ),
    KidsSong(
        "babyshark", "بیبی شارک", "🦈", "متوسط", 120,
        listOf(
            SongNote(1, 1f, "بیـ"), SongNote(2, 1f, "بی"),
            SongNote(4, 0.5f, "شارک"), SongNote(4, 0.5f, "دو"), SongNote(4, 0.5f, "دو"),
            SongNote(4, 0.5f, "دو"), SongNote(4, 0.5f, "دو"), SongNote(4, 0.5f, "دو"),
            SongNote(1, 0.5f, "بیـ"), SongNote(2, 0.5f, "بی"),
            SongNote(4, 1f, "شارک"), SongNote(3, 2f, "!")
        )
    ),
    KidsSong(
        "odetojoy", "سرود شادی (کامل)", "🎉", "متوسط", 112,
        listOf(
            SongNote(2, 1f, "شا"), SongNote(2, 1f, "دی"), SongNote(3, 1f, "با"), SongNote(4, 1f, "ما"),
            SongNote(4, 1f, "همـ"), SongNote(3, 1f, "را"), SongNote(2, 1f, "ه"), SongNote(1, 1f, "است"),
            SongNote(0, 1f, "در"), SongNote(0, 1f, "این"), SongNote(1, 1f, "رو"), SongNote(2, 1f, "ز"),
            SongNote(2, 1.5f, "زیـ"), SongNote(1, 0.5f, "بـ"), SongNote(1, 2f, "ا"),
            SongNote(2, 1f, "آ"), SongNote(2, 1f, "وا"), SongNote(3, 1f, "ز"), SongNote(4, 1f, "خو"),
            SongNote(4, 1f, "شـ"), SongNote(3, 1f, "حا"), SongNote(2, 1f, "لی"), SongNote(1, 1f, "ها"),
            SongNote(0, 1f, "پر"), SongNote(0, 1f, "از"), SongNote(1, 1f, "مهـ"), SongNote(2, 1f, "ر"),
            SongNote(1, 1.5f, "و"), SongNote(0, 0.5f, "صـ"), SongNote(0, 2f, "فا")
        )
    ),
    KidsSong(
        "jingle", "جینگل بلز", "🔔", "حرفه‌ای", 130,
        listOf(
            SongNote(2, 1f, "جینـ"), SongNote(2, 1f, "گل"), SongNote(2, 2f, "بلز"),
            SongNote(2, 1f, "جینـ"), SongNote(2, 1f, "گل"), SongNote(2, 2f, "بلز"),
            SongNote(2, 1f, "جینـ"), SongNote(4, 1f, "گل"), SongNote(0, 1.5f, "آل"), SongNote(1, 0.5f, "د"), SongNote(2, 2f, "وی")
        )
    ),
    KidsSong(
        "rowboat", "قایق سواری", "🚣", "خیلی آسان", 108,
        listOf(
            SongNote(0, 1f, "قا"), SongNote(0, 1f, "یق"), SongNote(0, 0.75f, "رو"),
            SongNote(1, 0.25f, "بـ"), SongNote(2, 2f, "ران"),
            SongNote(2, 0.75f, "آ"), SongNote(1, 0.25f, "را"), SongNote(2, 0.75f, "م"),
            SongNote(3, 0.25f, "در"), SongNote(4, 2f, "آب")
        )
    ),
    KidsSong(
        "lullaby", "لالایی آرام", "🌙", "آسان", 88,
        listOf(
            SongNote(2, 0.5f, "لا"), SongNote(2, 0.5f, "لا"), SongNote(4, 2f, "یی"),
            SongNote(2, 0.5f, "لا"), SongNote(2, 0.5f, "لا"), SongNote(4, 2f, "یی"),
            SongNote(2, 0.5f, "شب"), SongNote(4, 0.5f, "شـ"), SongNote(7, 1f, "ده"),
            SongNote(6, 1f, "آ"), SongNote(5, 1f, "را"), SongNote(5, 1f, "م"), SongNote(4, 2f, "بخواب")
        )
    )
)

val MUSIC_LESSONS = listOf(
    MusicLesson("l1", "درس ۱: آشنایی با نت‌ها", "از چپ به راست تمام ۸ تیغه رنگی را به ترتیب بنواز.", listOf(0, 1, 2, 3, 4, 5, 6, 7), 15),
    MusicLesson("l2", "درس ۲: صدای بم و زیر", "تیغه قرمز (بم) و صورتی (زیر) را یکی در میان بزن.", listOf(0, 7, 0, 7), 15),
    MusicLesson("l3", "درس ۳: پرش قورباغه", "روی نت‌های دو، می، سل و دو بالا بپر و برگرد!", listOf(0, 2, 4, 7, 4, 2, 0), 20),
    MusicLesson("l4", "درس ۴: اولین ملودی", "ملودی ساده دو، ر، می، دو را دو بار تکرار کن.", listOf(0, 1, 2, 0, 0, 1, 2, 0), 25)
)
