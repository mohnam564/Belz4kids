package com.belzmagic.nativeapp

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class Timbre(val label: String) {
    GLOCKENSPIEL("🔔 بلز کلاسیک"),
    MARIMBA("🪵 ماریمبا نرم"),
    MAGIC("✨ زنگ جادویی")
}

object GlockenspielSynth {
    private const val SAMPLE_RATE = 44100
    private val scope = CoroutineScope(Dispatchers.Default)

    fun playNote(freq: Double, timbre: Timbre = Timbre.GLOCKENSPIEL, muted: Boolean = false) {
        if (muted) return
        scope.launch {
            val durationSec = when (timbre) {
                Timbre.GLOCKENSPIEL -> 1.1
                Timbre.MARIMBA -> 0.6
                Timbre.MAGIC -> 1.3
            }
            val numSamples = (SAMPLE_RATE * durationSec).toInt()
            val pcm = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / SAMPLE_RATE
                val attack = if (t < 0.008) t / 0.008 else 1.0
                val sample = when (timbre) {
                    Timbre.GLOCKENSPIEL -> {
                        val f1 = sin(2.0 * PI * freq * t) * exp(-3.2 * t) * 0.60
                        val f2 = sin(2.0 * PI * freq * 2.756 * t) * exp(-8.5 * t) * 0.22
                        val f3 = sin(2.0 * PI * freq * 5.404 * t) * exp(-16.0 * t) * 0.08
                        (f1 + f2 + f3) * attack
                    }
                    Timbre.MARIMBA -> {
                        val f1 = sin(2.0 * PI * (freq * 0.5) * t) * exp(-5.0 * t) * 0.72
                        val f2 = sin(2.0 * PI * freq * 2.0 * t) * exp(-14.0 * t) * 0.15
                        (f1 + f2) * attack
                    }
                    Timbre.MAGIC -> {
                        val f1 = sin(2.0 * PI * freq * t) * exp(-2.5 * t) * 0.50
                        val f2 = sin(2.0 * PI * freq * 2.0 * t) * exp(-2.8 * t) * 0.30
                        (f1 + f2) * attack
                    }
                }
                val clamped = (sample * Short.MAX_VALUE * 0.85).toInt()
                    .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                pcm[i] = clamped.toShort()
            }

            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(pcm, 0, pcm.size)
                track.play()
                Thread.sleep((durationSec * 1000).toLong() + 50)
                track.stop()
                track.release()
            } catch (_: Exception) {
            }
        }
    }
}
