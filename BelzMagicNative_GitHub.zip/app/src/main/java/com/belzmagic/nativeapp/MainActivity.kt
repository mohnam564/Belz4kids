package com.belzmagic.nativeapp

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class AppTab(val title: String, val icon: String) {
    FREE("نوازندگی", "🎹"),
    SONGS("آهنگ‌ها", "🎵"),
    GAMES("بازی‌ها", "🎮"),
    LESSONS("درس‌ها", "🎓")
}

enum class LabelMode(val title: String) {
    FA("دو ر می"),
    NUM("۱ تا ۱۱"),
    EN("C D E"),
    NONE("فقط رنگ")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme {
                    BelzMagicScreen()
                }
            }
        }
    }
}

@Composable
fun BelzMagicScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("belz_prefs", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()

    var stars by remember { mutableIntStateOf(prefs.getInt("stars", 0)) }
    var muted by remember { mutableStateOf(false) }
    var timbre by remember { mutableStateOf(Timbre.GLOCKENSPIEL) }
    var labelMode by remember { mutableStateOf(LabelMode.FA) }
    var activeTab by remember { mutableStateOf(AppTab.FREE) }
    var barCount by remember { mutableIntStateOf(11) }
    var songSpeed by remember { mutableFloatStateOf(1.0f) }
    var mascotMsg by remember { mutableStateOf("سلام کوچولوی هنرمند! روی تیغه‌های رنگی بزن تا صدای جادویی بشنوی! 🎵") }
    var activeBarId by remember { mutableStateOf<Int?>(null) }

    // Recording & Playback
    var isRecording by remember { mutableStateOf(false) }
    var isPlayingRec by remember { mutableStateOf(false) }
    var playbackJob by remember { mutableStateOf<Job?>(null) }
    var recordStart by remember { mutableLongStateOf(0L) }
    val recorded = remember { mutableStateListOf<Pair<Int, Long>>() }

    // Songs
    var selectedSong by remember { mutableStateOf(KIDS_SONGS.first()) }
    var songStep by remember { mutableIntStateOf(0) }
    var isAutoPlaying by remember { mutableStateOf(false) }
    var autoPlayJob by remember { mutableStateOf<Job?>(null) }

    // Games: "ear", "memory", "hunt"
    var earTarget by remember { mutableStateOf<Int?>(null) }
    var earStreak by remember { mutableIntStateOf(0) }
    val memorySeq = remember { mutableStateListOf<Int>() }
    var memoryUserIdx by remember { mutableIntStateOf(0) }
    var memoryPlaying by remember { mutableStateOf(false) }
    var memoryJob by remember { mutableStateOf<Job?>(null) }
    var huntTarget by remember { mutableStateOf<Int?>(null) }
    var huntScore by remember { mutableIntStateOf(0) }
    var gameSubMode by remember { mutableStateOf("ear") }

    // Lessons
    var activeLesson by remember { mutableStateOf(MUSIC_LESSONS.first()) }
    var lessonStep by remember { mutableIntStateOf(0) }

    fun addStars(amount: Int) {
        stars += amount
        prefs.edit().putInt("stars", stars).apply()
    }

    fun stopAllPlayback() {
        playbackJob?.cancel()
        playbackJob = null
        isPlayingRec = false
        autoPlayJob?.cancel()
        autoPlayJob = null
        isAutoPlaying = false
        memoryJob?.cancel()
        memoryJob = null
        memoryPlaying = false
    }

    fun triggerBar(noteId: Int, fromUser: Boolean = true) {
        val note = BELZ_NOTES.getOrNull(noteId) ?: return
        GlockenspielSynth.playNote(note.freq, timbre, muted)
        activeBarId = noteId
        scope.launch {
            delay(160)
            if (activeBarId == noteId) activeBarId = null
        }

        if (!fromUser) return

        if (isRecording) {
            recorded.add(noteId to (System.currentTimeMillis() - recordStart))
        }

        when (activeTab) {
            AppTab.SONGS -> {
                val target = selectedSong.notes.getOrNull(songStep)
                if (target != null && target.noteId == noteId) {
                    songStep++
                    if (songStep >= selectedSong.notes.size) {
                        addStars(10)
                        mascotMsg = "آفرین! آهنگ «${selectedSong.title}» رو کامل نواختی! 🎉 (+۱۰ ستاره)"
                        songStep = 0
                    } else {
                        mascotMsg = "عالی! حالا نت بعدی: ${BELZ_NOTES[selectedSong.notes[songStep].noteId].fa} ✨"
                    }
                } else if (target != null) {
                    mascotMsg = "یه ذره دیگه! تیغه چشمک‌زن (${BELZ_NOTES[target.noteId].fa}) رو بزن 🌟"
                }
            }
            AppTab.GAMES -> {
                when (gameSubMode) {
                    "ear" -> {
                        val t = earTarget
                        if (t != null) {
                            if (noteId == t) {
                                earStreak++
                                addStars(3)
                                mascotMsg = "گوش طلایی! درست بود (${note.fa})! +۳ ستاره 🌟"
                                earTarget = null
                            } else {
                                earStreak = 0
                                mascotMsg = "نزدیک بود! دوباره به صدا گوش بده 💡"
                            }
                        }
                    }
                    "hunt" -> {
                        val ht = huntTarget
                        if (ht != null) {
                            if (noteId == ht) {
                                huntScore++
                                if (huntScore % 5 == 0) {
                                    addStars(5)
                                    mascotMsg = "فوق‌العاده! $huntScore امتیاز گرفتی! (+۵ ستاره) ⚡"
                                } else {
                                    mascotMsg = "آفرین! حالا نت بعدی رو پیدا کن 🎯"
                                }
                                huntTarget = Random.nextInt(barCount)
                            } else {
                                mascotMsg = "اوه! دنبال «${BELZ_NOTES[ht].fa}» بگرد 🔍"
                            }
                        }
                    }
                    else -> {
                        if (!memoryPlaying && memorySeq.isNotEmpty()) {
                            if (noteId == memorySeq[memoryUserIdx]) {
                                memoryUserIdx++
                                if (memoryUserIdx >= memorySeq.size) {
                                    addStars(4)
                                    mascotMsg = "مرحله ${memorySeq.size} رو بردی! (+۴ ستاره) 🎉"
                                    memorySeq.add(Random.nextInt(8))
                                    memoryUserIdx = 0
                                    memoryJob?.cancel()
                                    memoryJob = scope.launch {
                                        delay(800)
                                        memoryPlaying = true
                                        memorySeq.forEach { n ->
                                            triggerBar(n, false)
                                            delay(550)
                                        }
                                        memoryPlaying = false
                                        mascotMsg = "حالا نوبت توئه! همون نت‌ها رو تکرار کن 🎯"
                                    }
                                }
                            } else {
                                mascotMsg = "اشتباه شد! تا مرحله ${memorySeq.size} رفتی. دوباره شروع کن 💪"
                                memorySeq.clear()
                                memoryUserIdx = 0
                            }
                        }
                    }
                }
            }
            AppTab.LESSONS -> {
                val target = activeLesson.steps.getOrNull(lessonStep)
                if (target == noteId) {
                    lessonStep++
                    if (lessonStep >= activeLesson.steps.size) {
                        addStars(activeLesson.reward)
                        mascotMsg = "هورا! ${activeLesson.title} رو یاد گرفتی! (+${activeLesson.reward} ستاره) 🎓"
                        lessonStep = 0
                    }
                }
            }
            else -> {}
        }
    }

    val targetHighlightId: Int? = when (activeTab) {
        AppTab.SONGS -> selectedSong.notes.getOrNull(songStep)?.noteId
        AppTab.LESSONS -> activeLesson.steps.getOrNull(lessonStep)
        else -> null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFFFF9ED), Color(0xFFEEF7FF), Color(0xFFFDF2F8))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🎶", fontSize = 26.sp)
                Column {
                    Text("بلز جادویی", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color(0xFF1E1B4B))
                    Text("آموزش موسیقی کودکان", fontSize = 11.sp, color = Color(0xFF64748B))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFFFEF3C7),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCD34D))
                ) {
                    Text("⭐ $stars", modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                }
                IconButton(onClick = {
                    timbre = Timbre.entries[(timbre.ordinal + 1) % Timbre.entries.size]
                    GlockenspielSynth.playNote(BELZ_NOTES[4].freq, timbre, muted)
                }) {
                    Text(timbre.label.take(2), fontSize = 20.sp)
                }
                IconButton(onClick = { muted = !muted }) {
                    Text(if (muted) "🔇" else "🔊", fontSize = 20.sp)
                }
            }
        }

        // Mascot Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            shadowElevation = 2.dp
        ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("🐥", fontSize = 28.sp)
                Text(mascotMsg, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
            }
        }

        // Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            AppTab.entries.forEach { tab ->
                val selected = tab == activeTab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) Color(0xFF6366F1) else Color.Transparent)
                        .clickable {
                            stopAllPlayback()
                            activeTab = tab
                        }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "${tab.icon} ${tab.title}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        color = if (selected) Color.White else Color(0xFF475569)
                    )
                }
            }
        }

        // Dynamic Mode Panel
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            shadowElevation = 2.dp
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (activeTab) {
                    AppTab.FREE -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "🎹 ضبط آزاد (${recorded.size} نت)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = {
                                        if (isRecording) {
                                            isRecording = false
                                        } else {
                                            stopAllPlayback()
                                            recorded.clear()
                                            recordStart = System.currentTimeMillis()
                                            isRecording = true
                                        }
                                    },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = if (isRecording) Color(0xFFE11D48) else Color(0xFFF43F5E))
                                ) {
                                    Text(if (isRecording) "⏹️ توقف" else "🔴 ضبط", fontSize = 12.sp, maxLines = 1, softWrap = false)
                                }
                                Button(
                                    onClick = {
                                        if (isPlayingRec) {
                                            stopAllPlayback()
                                        } else {
                                            isRecording = false
                                            val snapshot = recorded.toList()
                                            if (snapshot.isNotEmpty()) {
                                                isPlayingRec = true
                                                playbackJob?.cancel()
                                                playbackJob = scope.launch {
                                                    var prev = 0L
                                                    for ((n, t) in snapshot) {
                                                        if (!isPlayingRec) break
                                                        delay((t - prev).coerceAtLeast(0L))
                                                        prev = t
                                                        triggerBar(n, false)
                                                    }
                                                    isPlayingRec = false
                                                }
                                            }
                                        }
                                    },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    enabled = recorded.isNotEmpty()
                                ) {
                                    Text(if (isPlayingRec) "⏹️ توقف" else "▶️ پخش", fontSize = 12.sp, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }

                    AppTab.SONGS -> {
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            KIDS_SONGS.forEach { song ->
                                val sel = song.id == selectedSong.id
                                FilterChip(
                                    selected = sel,
                                    onClick = {
                                        stopAllPlayback()
                                        selectedSong = song
                                        songStep = 0
                                        if (song.notes.any { it.noteId >= 8 } && barCount < 11) {
                                            barCount = 11
                                        }
                                    },
                                    label = { Text("${song.emoji} ${song.title}", fontSize = 12.sp, maxLines = 1, softWrap = false) }
                                )
                            }
                        }
                        val curItem = selectedSong.notes[songStep]
                        val durTag = when {
                            curItem.beats >= 1.5f -> "▬▬ کشیده"
                            curItem.beats <= 0.5f -> "⚡ سریع"
                            else -> "● عادی"
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "نت فعلی: ${BELZ_NOTES[curItem.noteId].fa} ${if (curItem.lyric.isNotEmpty()) "«${curItem.lyric}»" else ""} (${songStep + 1}/${selectedSong.notes.size})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    maxLines = 1
                                )
                                Text("کشش: $durTag • ${(selectedSong.bpm * songSpeed).toInt()} BPM", fontSize = 11.sp, color = Color(0xFF64748B))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedButton(
                                    onClick = { songSpeed = if (songSpeed < 1f) 1.0f else 0.7f },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(if (songSpeed < 1f) "🐢" else "🐇", fontSize = 13.sp, maxLines = 1, softWrap = false)
                                }
                                Button(
                                    onClick = {
                                        if (isAutoPlaying) {
                                            stopAllPlayback()
                                        } else {
                                            stopAllPlayback()
                                            isAutoPlaying = true
                                            autoPlayJob = scope.launch {
                                                val beatMs = (60_000f / selectedSong.bpm) / songSpeed
                                                for ((idx, item) in selectedSong.notes.withIndex()) {
                                                    if (!isAutoPlaying) break
                                                    songStep = idx
                                                    triggerBar(item.noteId, false)
                                                    delay((item.beats * beatMs).toLong())
                                                }
                                                isAutoPlaying = false
                                                songStep = 0
                                            }
                                        }
                                    },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(if (isAutoPlaying) "⏹️ توقف" else "👂 پخش", fontSize = 12.sp, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }

                    AppTab.GAMES -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilterChip(
                                    selected = gameSubMode == "ear",
                                    onClick = { stopAllPlayback(); gameSubMode = "ear" },
                                    label = { Text("👂 حدس نت ($earStreak🔥)", fontSize = 11.sp, maxLines = 1, softWrap = false) }
                                )
                                FilterChip(
                                    selected = gameSubMode == "memory",
                                    onClick = { stopAllPlayback(); gameSubMode = "memory" },
                                    label = { Text("🧠 حافظه", fontSize = 11.sp, maxLines = 1, softWrap = false) }
                                )
                                FilterChip(
                                    selected = gameSubMode == "hunt",
                                    onClick = { stopAllPlayback(); gameSubMode = "hunt" },
                                    label = { Text("⚡ شکار نت ($huntScore)", fontSize = 11.sp, maxLines = 1, softWrap = false) }
                                )
                            }
                            Spacer(Modifier.width(6.dp))
                            Button(
                                onClick = {
                                    stopAllPlayback()
                                    when (gameSubMode) {
                                        "ear" -> {
                                            val r = Random.nextInt(8)
                                            earTarget = r
                                            GlockenspielSynth.playNote(BELZ_NOTES[r].freq, timbre, muted)
                                            mascotMsg = "گوش کن! کدوم تیغه این صدا رو داد؟ 👂"
                                        }
                                        "hunt" -> {
                                            val r = Random.nextInt(barCount)
                                            huntTarget = r
                                            mascotMsg = "زود تیغه «${BELZ_NOTES[r].fa}» رو پیدا کن! ⚡"
                                        }
                                        else -> {
                                            memorySeq.clear()
                                            memorySeq.add(Random.nextInt(8))
                                            memoryUserIdx = 0
                                            memoryJob = scope.launch {
                                                memoryPlaying = true
                                                triggerBar(memorySeq.first(), false)
                                                delay(450)
                                                memoryPlaying = false
                                                mascotMsg = "همون تیغه رو بزن! 🎯"
                                            }
                                        }
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    when (gameSubMode) {
                                        "ear" -> "🔊 صدا"
                                        "hunt" -> "⚡ شروع"
                                        else -> "▶️ شروع"
                                    },
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }

                    AppTab.LESSONS -> {
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            MUSIC_LESSONS.forEach { lesson ->
                                FilterChip(
                                    selected = lesson.id == activeLesson.id,
                                    onClick = {
                                        activeLesson = lesson
                                        lessonStep = 0
                                        if (lesson.steps.any { it >= 8 } && barCount < 11) {
                                            barCount = 11
                                        }
                                    },
                                    label = { Text(lesson.title.substringBefore(":"), fontSize = 12.sp, maxLines = 1, softWrap = false) }
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(activeLesson.desc, fontSize = 12.sp, color = Color(0xFF475569), modifier = Modifier.weight(1f))
                            Text(" ${lessonStep}/${activeLesson.steps.size} • ⭐+${activeLesson.reward}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                        }
                    }
                }
            }
        }

        // Label & Bar Count Selector
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("برچسب:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            LabelMode.entries.forEach { mode ->
                FilterChip(
                    selected = labelMode == mode,
                    onClick = { labelMode = mode },
                    label = { Text(mode.title, fontSize = 11.sp, maxLines = 1, softWrap = false) }
                )
            }
            FilterChip(
                selected = barCount == 11,
                onClick = { barCount = if (barCount == 11) 8 else 11 },
                label = { Text(if (barCount == 11) "🎹 ۱۱ نت" else "🎹 ۸ نت", fontSize = 11.sp, maxLines = 1, softWrap = false) }
            )
        }

        // Rainbow Glockenspiel (LTR order: C5 -> F6)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            var gridSize by remember { mutableStateOf(IntSize.Zero) }
            var lastDraggedNote by remember { mutableStateOf<Int?>(null) }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFFD99B52), Color(0xFFB87631))))
                    .border(3.dp, Color(0xFF965B20), RoundedCornerShape(24.dp))
                    .padding(10.dp)
                    .onGloballyPositioned { gridSize = it.size }
                    .pointerInput(barCount) {
                        detectDragGestures(
                            onDragEnd = { lastDraggedNote = null },
                            onDragCancel = { lastDraggedNote = null }
                        ) { change, _ ->
                            if (gridSize.width > 0) {
                                val idx = ((change.position.x / gridSize.width) * barCount)
                                    .toInt().coerceIn(0, barCount - 1)
                                if (lastDraggedNote != idx) {
                                    lastDraggedNote = idx
                                    triggerBar(idx, true)
                                }
                            }
                        }
                    }
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(if (barCount == 11) 4.dp else 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BELZ_NOTES.take(barCount).forEach { note ->
                        val isPressed = activeBarId == note.id
                        val isTarget = targetHighlightId == note.id
                        val scale by animateFloatAsState(if (isPressed) 0.94f else 1f, label = "barScale")

                        val textLabel = when (labelMode) {
                            LabelMode.FA -> note.fa
                            LabelMode.NUM -> note.num
                            LabelMode.EN -> note.en
                            LabelMode.NONE -> "●"
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(note.heightFraction)
                                .scale(scale)
                                .shadow(if (isPressed) 2.dp else 8.dp, RoundedCornerShape(14.dp))
                                .clip(RoundedCornerShape(14.dp))
                                .background(Brush.verticalGradient(listOf(note.topColor, note.bottomColor)))
                                .then(
                                    if (isTarget) Modifier.border(3.dp, Color(0xFFFACC15), RoundedCornerShape(14.dp))
                                    else Modifier
                                )
                                .pointerInput(note.id) {
                                    detectTapGestures(onPress = {
                                        triggerBar(note.id, true)
                                        tryAwaitRelease()
                                    })
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize().padding(vertical = 8.dp),
                                verticalArrangement = Arrangement.SpaceBetween,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.85f)))
                                Text(textLabel, color = Color.White, fontWeight = FontWeight.Black, fontSize = if (barCount == 11) 12.sp else 15.sp, maxLines = 1, softWrap = false)
                                Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.85f)))
                            }
                        }
                    }
                }
            }
        }
    }
}
